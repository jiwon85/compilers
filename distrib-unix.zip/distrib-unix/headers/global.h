#ifndef  GLOBALHEADER
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*      global.h                                                             */
/*                                                                           */
/*      Header file containing definitions used throughout the compiler.     */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#define  GLOBALHEADER

#define  PUBLIC
#define  PRIVATE  static
#endif
